# Paquete de utilidades compartidas.
