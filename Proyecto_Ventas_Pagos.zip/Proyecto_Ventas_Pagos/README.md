# Proyecto de ventas y pagos (Python + MVC)

## Requisitos
- Python 3.9 o superior.
- No necesita instalar librerías externas.

## Ejecutar
Abre una terminal dentro de esta carpeta y ejecuta:

```bash
python main.py
```

En Windows también puedes usar `py main.py`.

## Qué incluye
- CRUD de clientes, productos y ventas.
- Persistencia local en archivos JSON dentro de `data/`.
- Nuevo menú **Pagos** con realizar pago, consultar pago, listar pagos, buscar y ver ventas pendientes.
- Un solo pago por venta; efectivo valida el monto y calcula el cambio; tarjeta/transferencia cobran el total exacto.
- Resumen de ventas pendientes y total cobrado.
- Reto opcional aplicado: no permite anular una venta pagada.

## Comentarios de la tarea
En `models.py`, `views.py` y `main.py`, los bloques añadidos para cumplir la tarea están marcados con comentarios `TAREA:`. El código base de `shared/`, `CrudBase`, y los controladores originales se conserva.

## Prueba manual sugerida
1. Crea un cliente, por ejemplo Ana Pérez.
2. Crea un producto, por ejemplo Teclado, precio `25.50`, stock `6`.
3. Registra una venta de 2 teclados. El subtotal será `$51.00` y el total con IVA del 15 % será `$58.65`.
4. En **Pagos → Ventas pendientes**, confirma que aparece la venta.
5. Intenta pagar en efectivo con `50`: debe rechazarlo porque faltan `$8.65`.
6. Paga la venta con efectivo y `60`: debe registrar el pago y mostrar `$1.35` de cambio.
7. Intenta pagar de nuevo la misma venta: debe impedir el segundo pago.
8. Consulta el pago y revisa el recibo.
9. Comprueba que `data/pagos.json` conserva el pago después de cerrar y abrir el programa.
